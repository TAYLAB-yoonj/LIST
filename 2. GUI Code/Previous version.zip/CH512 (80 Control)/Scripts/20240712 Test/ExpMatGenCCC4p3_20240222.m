% 1 is open, 0 is closed
% Experiment Started: XX:XX

input = [                               %       9, 10, 11, 12, 13, 14    
    9, 10, 11, 12, 13, 14               %        DIW, So, Ca, M1, M2, M3
       ];                                    

fm=0; % offsets for chip 1
OS = 0:1:10;

exp = [ % [Time (min)], [input#], [ch#], [Left, right, or, Paired? (0: Left, 1: Right, 2: Paired)], [Donout?  1 = yes, 0 = no]
 
0+OS(1),          0,  9,   0, 1; 
1+OS(1),          0,  9,   0, 2; 

2+OS(1),          fm,  12,   0, 0; 
3+OS(2),          fm,  12,   1, 0;

]; 

[nr,nc] = size(exp);
expMat = [];
for aa=1:nr
    [M, I] = min(exp(:,1));
    expMat = [expMat; exp(I,:)];
    exp(I,:) = [];
end

save ExpMat_20240912_Bacteria.mat expMat