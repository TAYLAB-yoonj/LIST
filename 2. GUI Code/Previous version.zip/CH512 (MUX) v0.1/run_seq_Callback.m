function run_seq_Callback(hObject, eventdata, handles)
global GUI vc

for i=1:GUI.seq
    
    butSeq=GUI.buttonSeq(i);
    butTime=GUI.buttonTime(i);
    if ~isempty(butSeq.String) && ~isempty(butTime.String)
        try
            aa=cell2mat(textscan(butSeq.String, '%u64'))';
            delay=str2double(butTime.String);
            vc = vc_set_bits_ac(vc, aa, ones(1,numel(aa)));
            pause(delay)
            vc = vc_set_bits_ac(vc, aa, zeros(1,numel(aa)));
            scr_update(['Sequence ' num2str(i) ' has been completed']);
        catch
            errordlg('Error while running the sequence!');
        end
    elseif isempty(butSeq.String) | isempty(butTime.String)
        errordlg('You need to indicate the Valves and Time you are controlling!!')
        scr_update('You need to indicate the Valves and Time you are controlling!!');
    end
end