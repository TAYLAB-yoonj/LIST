function load_seq_Callback(hObject, eventdata, handles)
global GUI vc

scr_update('Loading sequences');

if GUI.scRunning == 1
    str = ['Cannot change the script folder, while a script is running!'];
    scr_update(str);
    errordlg(str, 'Script Folder');
else
    [file,location,indx] = uigetfile('*.mat');
    if file
        load(file,'datTable')
        GUI.tab.Data=datTable;
        scr_update(['Loading file ' file]);
        scUpdate_Callback;
    end
end

    GUI.button(GUI.tot+10).BackgroundColor=[.7 .7 .7];
    
end