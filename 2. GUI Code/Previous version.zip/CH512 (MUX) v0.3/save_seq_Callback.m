function save_seq_Callback(hObject, eventdata, handles)
global GUI vc

scr_update('Saving sequences');
datTable=GUI.tab.Data;
[filename,location,indx] = uiputfile('datTable.mat');

if filename
save(filename,'datTable') 
end

end
