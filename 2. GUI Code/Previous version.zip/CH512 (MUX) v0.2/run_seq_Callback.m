function run_seq_Callback(hObject, eventdata, handles)
global GUI vc

GUI.seqStop=0;
GUI.seqPause=0;
GUI.button(GUI.tot+6).Enable='off';
seq=1;

scr_update('Start running the sequence');
while GUI.seqStop==0 && seq<GUI.seq
    if GUI.seqPause==0
        seq=seq+1;
        GUI.button(GUI.tot+7).BackgroundColor='y';
        GUI.button(GUI.tot+8).BackgroundColor='r';
        butSeq=GUI.buttonSeq(seq);
        butTime=GUI.buttonTime(seq);
        if ~isempty(butSeq.String) && ~isempty(butTime.String)
            try
                scr_update(['Running sequence ' num2str(seq-1)]);
                aa=cell2mat(textscan(butSeq.String, '%f'))';
                delay=str2double(butTime.String);
                vc = vc_set_bits_ac(vc, aa, ones(1,numel(aa)));
                pause(delay)
                vc = vc_set_bits_ac(vc, aa, zeros(1,numel(aa)));
            catch e
                errordlg('Error while running the sequence!');
                fprintf(1,'\nThe identifier was: %s',e.identifier);
                fprintf(1,'\nThere was an error: %s',e.message);
            end
        elseif isempty(butSeq.String) || isempty(butTime.String)
            GUI.seqStop=1;
            GUI.button(GUI.tot+7).BackgroundColor=[.7 .7 .7];
            GUI.button(GUI.tot+8).BackgroundColor=[.7 .7 .7];
            GUI.button(GUI.tot+6).Enable='on';
            errordlg('You need to indicate the Valves and Time you are controlling!!')
            scr_update('You need to indicate the Valves and Time you are controlling!!');
        end
    else
        scr_update('The sequence has been paused!!!');
        pause(10)
    end
end

    GUI.button(GUI.tot+7).BackgroundColor=[.7 .7 .7];
    GUI.button(GUI.tot+8).BackgroundColor=[.7 .7 .7];
    GUI.button(GUI.tot+6).Enable='on';
    
    butSeq=GUI.buttonSeq(1);
    butTime=GUI.buttonTime(1);
    if ~isempty(butSeq.String) 
            try
                scr_update(['Returning to initisl condition']);
                aa=cell2mat(textscan(butSeq.String, '%f'))';
                vc = vc_set_bits_ac(vc, aa, ones(1,numel(aa)));
            catch e
                errordlg('Error while running the sequence!');
                fprintf(1,'\nThe identifier was: %s',e.identifier);
                fprintf(1,'\nThere was an error: %s',e.message);
            end
    end
