function save_seq_Callback(hObject, eventdata, handles)
global GUI vc

stable={};
% [file,location,indx] = uiputfile('sequence.mat');
scr_update('Saving sequences');
for seq=1:GUI.seq
        GUI.button(GUI.tot+9).BackgroundColor='b';
        butSeq=GUI.buttonSeq(seq);
        butTime=GUI.buttonTime(seq);
        butMemo=GUI.buttonMemo(seq);
        if ~isempty(butSeq.String) && ~isempty(butTime.String)
            try
                aa=butSeq.String;
                delay=butTime.String;
                memo=butMemo.String;
                stable{seq}.seqNum=seq;
                stable{seq}.seq=aa;
                stable{seq}.time=delay;
                stable{seq}.memo=memo;
            catch e
                errordlg('Error while saving the sequence!');
                fprintf(1,'\nThe identifier was: %s',e.identifier);
                fprintf(1,'\nThere was an error: %s',e.message);
            end
        elseif isempty(butSeq.String) || isempty(butTime.String)
            GUI.seqStop=1;
            GUI.button(GUI.tot+7).BackgroundColor=[.7 .7 .7];
            GUI.button(GUI.tot+8).BackgroundColor=[.7 .7 .7];
            GUI.button(GUI.tot+6).Enable='on';
            errordlg('You need to indicate the Valves and Time you are controlling!!')
            scr_update('You need to indicate the Valves and Time you are controlling!!');
        end
end

    GUI.button(GUI.tot+9).BackgroundColor=[.7 .7 .7];
    save sequence.mat stable
    
end
