function load_seq_Callback(hObject, eventdata, handles)
global GUI vc

load sequence.mat 
scr_update('Loading sequences');

for seq=1:GUI.seq
    delete(GUI.buttonSeqText(seq));
    delete(GUI.buttonSeq(seq));
    delete(GUI.buttonTime(seq));
    delete(GUI.buttonMemo(seq));
end

GUI.seq=0;
for seq=1:numel(stable)
        GUI.button(GUI.tot+10).BackgroundColor='b';
        add_seq_Callback
        GUI.buttonSeq(seq).String=stable{seq}.seq;
        GUI.buttonTime(seq).String=stable{seq}.time;
        GUI.buttonMemo(seq).String=stable{seq}.memo;
end

    GUI.button(GUI.tot+10).BackgroundColor=[.7 .7 .7];
    
end