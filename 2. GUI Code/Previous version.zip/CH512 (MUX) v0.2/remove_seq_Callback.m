function remove_seq_Callback(hObject, eventdata, handles)
global GUI vc

if GUI.seq>1
delete(GUI.buttonSeqText(GUI.seq));
delete(GUI.buttonSeq(GUI.seq));
delete(GUI.buttonTime(GUI.seq));
delete(GUI.buttonMemo(GUI.seq));

GUI.seq=GUI.seq-1;
end

end