% 1 is open, 0 is closed
% Experiment Started: 19:52
% Other Notes: CH 25 L is bad
% Fibronectin coating in all
% 90s flush built into code for all inputs

input = [                               %             0      1        2     3     4     5    6          7
    0, 1, 2,  3, 4, 5, 6, 7, ...        %        LPS  1    LPS 3  LPS 10  
    ...
    16, 17,  18, 19,  20, 21            % 16        17         18       19       20       21         
    ];                                  %          Kanamycin  Lb+Carb  CaCl2   Sodium C   LSP 0.3    


fm=0;
% offsets for chip 1
OS = 0:2:138;

exp = [ % [Time (min)], [input#], [ch#], [Left, right, or, Paired? (0: Left, 1: Right, 2: Paired)], [Donout?  1 = yes, 0 = no]
 

0+OS(1),          0,  15,   0, 1; 
5*60-2+OS(1),          0,  15,   0, 2; 


5*60+OS(1),          fm,  12,   0, 0; 
5*60+OS(2),          fm,  12,   1, 0;

5*60+OS(3),          fm,  13,   0, 0; 
5*60+OS(4),          fm,  13,   1, 0;

5*60+OS(5),          fm,  14,   0, 0; 
5*60+OS(6),          fm,  14,   1, 0;

5*60+OS(7),          fm,  15,   0, 0; 
5*60+OS(8),          fm,  15,   1, 0;

5*60+OS(9),          fm,  16,   0, 0; 
5*60+OS(10),          fm,  16,   1, 0;

10*60+OS(1),          fm,  12,   0, 0; 
10*60+OS(2),          fm,  12,   1, 0;

10*60+OS(3),          fm,  13,   0, 0; 
10*60+OS(4),          fm,  13,   1, 0;

10*60+OS(5),          fm,  14,   0, 0; 
10*60+OS(6),          fm,  14,   1, 0;

10*60+OS(7),          fm,  15,   0, 0; 
10*60+OS(8),          fm,  15,   1, 0;

10*60+OS(9),          fm,  16,   0, 0; 
10*60+OS(10),          fm,  16,   1, 0;

15*60+OS(1),          fm,  12,   0, 0; 
15*60+OS(2),          fm,  12,   1, 0;

15*60+OS(3),          fm,  13,   0, 0; 
15*60+OS(4),          fm,  13,   1, 0;

15*60+OS(5),          fm,  14,   0, 0; 
15*60+OS(6),          fm,  14,   1, 0;

15*60+OS(7),          fm,  15,   0, 0; 
15*60+OS(8),          fm,  15,   1, 0;

15*60+OS(9),          fm,  16,   0, 0; 
15*60+OS(10),          fm,  16,   1, 0;

]; 

[nr,nc] = size(exp);
expMat = [];
for aa=1:nr
    [M, I] = min(exp(:,1));
    expMat = [expMat; exp(I,:)];
    exp(I,:) = [];
end

save ExpMat_20240222_Bacteria_Raw.mat expMat