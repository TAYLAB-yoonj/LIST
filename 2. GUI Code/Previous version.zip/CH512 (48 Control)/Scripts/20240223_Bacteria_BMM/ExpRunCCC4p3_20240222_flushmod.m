 %90s wash, 1/2 chip feeding option
%21:00 starting point
global vc p1 GUI

GUI.scStop = 0;

%VALVE CONTROL VARIABLES
mux = [
    22 23 24 25 26 27 28 29 30 31
    ];
Purge1   = 11;    % Purgeoutlet for first set of inlets
Purge2   = 8;     % Purgeoutlet for second set of inlets
Frin     = 0;    % FM to wash the paths
bypass   = [34 38];
chamberin = [33 32 37 36];     % [33 32 37 36]
donouts=[41 43];

bponoroff = 0; % open the bypass when feeding the chambers? 1 means open bp; 0 means close. Think about the washing time and sheer stress. Default is 0

% TIME PARAMETERS (in seconds)
% Total time=2*ft0 + 2*ft1 + ft2 + ft3 + wt1 + 2
ft0 = 2; % 2;    % flushing time 0 for initial washing thru purge2
ft1 = 4; % 4;    % flushing time 1 for washing thru purge1 and multiplexer
ft2 = 10; % 8;    % flushing time 2 for filling the path with new medium
ft3 = 10; % 8;    % flushing time 3 for washing all multiplexer pathway after feeding
wt1 = 15; % 7;    % feeding time /chamber

ftPre = 60;     %time to flush inputs prior to feeding

wt_all = 90; % feeding time if feeding all chambers
ft_all = 20; %flushing time if feeding all chambers

load('ExpMat_20240222_Bacteria_Raw.mat');
[nr,nc]=size(expMat);
delay = 60;  % min
inputs = unique(expMat(:, 2) );
lastuse = zeros(length(inputs));

for nn=1:nr
    expMat(nn,1) = now + (expMat(nn,1)+delay)/(24*60);
end
expMatF = [];

vc = vc_set_bits_ac(vc, [9 40 42], [1 1 1]); %unused controls

vc = vc_set_bits_ac(vc, [35 39], [0 0]); %unused controls

while ~isempty(expMat) && GUI.scStop == 0
    if expMat(1,1) <= now
        cur_in = expMat(1,2);   %time, input#, ch#, [Left, right, or both ch], extra input
        
        % Building in flushing - ALL INPUTS
        if cur_in < 8
            vc = vc_set_bits_ac(vc, [cur_in 10 11], [1 1 1]);
            scr_update(['Flushing input: ' num2str(cur_in) ]);
            pause(ftPre)
            vc = vc_set_bits_ac(vc, [cur_in 10 11], [0 0 0]);
        elseif cur_in>=8 && cur_in< 22 
            vc = vc_set_bits_ac(vc, [cur_in 8], [1 1]);
            scr_update(['Flushing input: ' num2str(cur_in) ]);
            pause(ftPre)
            vc = vc_set_bits_ac(vc, [cur_in 8], [0 0]);
        end
        
        
        if expMat(1,5) == 0
            chnum = expMat(1,3);
            if chnum <= 16
                bpass = bypass(1);
                chin = chamberin(1:2);
                %             bpass = bypass(2);
                %             chin = chamberin(3:4);
            else
                bpass = bypass(2);
                chin = chamberin(3:4);
                %             bpass = bypass(1);
                %             chin = chamberin(1:2);
            end
            scr_update(['Preparing to feed ch' num2str(chnum) ' with input' num2str(cur_in)]);
            
            set_mux_CCC4(mux, chnum);    %open multiplexer controls to desired chamber
            vc = vc_set_bits_ac(vc, bpass, 1); %open bypass
            
            %pre-wash with fresh media
            vc = vc_set_bits_ac(vc, [Frin Purge1 Purge2 14 15], [1 1 1 1 1]);
            vc = vc_set_bits_ac(vc, 0:1:7, [1 1 1 1 1 1 1 1]);
            pause(ft0);
            vc = vc_set_bits_ac(vc, Purge2, 0);
            pause(ft1);
            vc = vc_set_bits_ac(vc, [Frin Purge1 14 15], [0 0 0 0]);
            vc = vc_set_bits_ac(vc, 0:1:7, [0 0 0 0 0 0 0 0]);
            
            %fill channel with sample media
            vc = vc_set_bits_ac(vc, cur_in, 1); %open sample input
            if cur_in <= 8
                vc = vc_set_bits_ac(vc, 14, 1);
                vc = vc_set_bits_ac(vc, 10, 1);
            else
                vc = vc_set_bits_ac(vc, 15, 1);
            end
            
            pause(ft2);                     %filling the channels with new medium
            
            %feed chambers
            if bponoroff == 0                  %if specified, close bypass
                vc = vc_set_bits_ac(vc, bpass, 0);
            end
            if expMat(1,4) == 0
                vc = vc_set_bits_ac(vc, chin(1), 1);  %open left chamber
                scr_update(['Feeding ch' num2str(chnum) 'L']);
            elseif expMat(1,4) == 1
                vc = vc_set_bits_ac(vc, chin(2), 1);  %open right chamber
                scr_update(['Feeding ch' num2str(chnum) 'R']);
            elseif expMat(1,4) == 2
                vc = vc_set_bits_ac(vc, chin, [1 1]);  %open both chambers
                scr_update(['Feeding ch' num2str(chnum) 'B']);
            end
            expMatF = [expMatF; expMat(1,:), now];  %Recording the actual feeding time to cell chambers
            pause(wt1);                          %fill chambers with sample media
            vc = vc_set_bits_ac(vc, bpass, 1); %open bypass
            vc = vc_set_bits_ac(vc, chin, [0 0]);  %close chambers
            vc = vc_set_bits_ac(vc, cur_in, 0); %close sample input
            vc = vc_set_bits_ac(vc, 10, 0);
            pause(1);
            
            %post-wash with fresh media
            vc = vc_set_bits_ac(vc, mux(3:end), [1 1 1 1 1 1 1 1]);
            vc = vc_set_bits_ac(vc, bpass, 1); %open bypass
            vc = vc_set_bits_ac(vc, [Frin Purge1 Purge2 14 15], [1 1 1 1 1]);
            vc = vc_set_bits_ac(vc, 0:1:7, [1 1 1 1 1 1 1 1]);
            pause(ft0);
            vc = vc_set_bits_ac(vc, Purge2, 0);
            pause(ft1);
            vc = vc_set_bits_ac(vc, [Purge1 14], [0 0]);
            vc = vc_set_bits_ac(vc, 0:1:7, [0 0 0 0 0 0 0 0]);
            pause(ft3);
            
            %close everything
            vc = vc_set_bits_ac(vc, [Frin Purge1 Purge2 14 15], [0 0 0 0 0]);
            set_mux_CCC4(mux, 99); %98 open everything, 99 close everything in multiplexer
            vc = vc_set_bits_ac(vc, bpass, 0); %close bypass
            expMat(1,:) = [];
            
        elseif expMat(1,5) == 1 %Open Donuts
            chnum = expMat(1,3);
            if chnum <= 16
                don=donouts(1);
            else
                don=donouts(2);
            end
            vc = vc_set_bits_ac(vc, don, 1);
            expMatF = [expMatF; expMat(1,:), now];  %Recording the actual feeding time to cell chambers

             %close everything
            vc = vc_set_bits_ac(vc, [Frin Purge1 Purge2 14 15], [0 0 0 0 0]);
            set_mux_CCC4(mux, 99); %98 open everything, 99 close everything in multiplexer
            vc = vc_set_bits_ac(vc, bpass, 0); %close bypass

            expMat(1,:) = [];

       elseif expMat(1,5) == 2 %Close Donuts
            chnum = expMat(1,3);
            if chnum <= 16
                don=donouts(1);
            else
                don=donouts(2);
            end
            vc = vc_set_bits_ac(vc, don, 0);
            expMatF = [expMatF; expMat(1,:), now];  %Recording the actual feeding time to cell chambers

             %close everything
            vc = vc_set_bits_ac(vc, [Frin Purge1 Purge2 14 15], [0 0 0 0 0]);
            set_mux_CCC4(mux, 99); %98 open everything, 99 close everything in multiplexer
            vc = vc_set_bits_ac(vc, bpass, 0); %close bypass

            expMat(1,:) = [];
            
        end
        save ExpSch_20240222_Bacteria_Raw expMatF
    end
    pause(1);
end

save ExpSch_20240222_Bacteria_Raw expMatF